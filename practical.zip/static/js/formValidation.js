 
function validate()
{
     var settings = {
              //set #id for hiring
                hiring:"#hiringFunction",
                hiringLocation : "#hiringLocation",
                //set id for RFA 
                RFA: "#RFHnumber",
                ErrorTextRFA : "Please enter a valid RFA number.",
                ErrorTextEmpty : "Cannot be empty",
                //set #id for consultant name
                consultantName: "#consultantName",
                ErrorAlpha : "Please enter only  characters",
                ErrorNumeric : "Please enter only numeric characters",
                ErrorTextRFAConsulantEmpty : "Cannot be empty",
                ErrorDropdown : "Please choose one.",
                //set #id for employee name
                employeeName : "#employeeName",
                EmployeeCode : "#EmployeeCode",
                //set #id for HR
                LineHrName : "#HRname",
                LineHrCode :"#HRCode",
                    
                //candidate details 
                CandidateName: "#cand_name",
                DOB : '#DOB',
                Mobile:"#mobile",
                ErrorTextMobile:"Please enter a valid phone number.",
                ErrorTextMobileLength:"Mobile number cannot exceed 10 characters",
           
                emailID: '#email',
                ErrorTextEmail: 'Please enter a valid email address. (email@domain.com)',
                
                gender : "#gender-check",
                ErrorRadio : "Please choose one.",
                    
                Address:"#address",
                ErrorAddressLength:"Address cannot exceed 200 characters.",
                    
                Country:"#country", 
                State:"#state",
                    
                ZIP: "#zip",
                ZipError : "Please enter a valid Pin code.",
                ZipErrorLength :"Pin code cannot exceed six characters.",
                
                MaritalStatus:"#maritalStatus",
                    
                Dependants:"#dependants",
                ErrorDependants:"Cannot exceed 100.",
                
                Aadhar:"#aadhar",
                ErrorAadhar :"Please enter a valid Aadhar number.",
                ErrorAadharLength :"Aadhar cannot exceed 12 characters.",
                
                PAN:"#pan",
                ErrorPan:"Please enter a valid PAN number",
                ErrorPanLength:"PAN Number cannot exceed 10 characters.",
            
                //questionaire
                CheckReference:"#CheckReference",
                CheckforLeads:"#CheckforLeads",                
                CheckforUnderstanding:"#CheckforUnderstanding",                
                CheckforRoleUnderstanding:"#CheckforRoleUnderstanding",                    
                CheckforProspects:"#CheckforProspects",
                CheckforProspectsConversion:"#CheckforProspectsConversion",
                CheckforContacts:"#CheckforContacts",
                  
                //work experience details    
                YearsWorked: "#years",
                MonthsWorked: "#months",
                ErrorMonthsLength: "Number of months cannot exceed 12.",                    
                InsuranceCheck:"#CheckInsurance",
                ArmyCheck:"#CheckArmy",
                EmployedCheck: "#checkEmployed",
                
                ErrorYear:"Please enter a valid year.",
                    
                //Previous Comapany Details
                Sector:".",
                Resume:'#resume',
                ErrorFileFormat:"Please select a file with valid extensions. (.pdf or .doc or .docx)",
                    
               
               //  set #id for validation password
               passwordID: '#inputPassword',
               //  set text for validation password
               ErrorTextPassword: 'Must be 7-20 characters long.',
                //  set value required chars for validation password
               MinCharsPass: '7',
               //  set #id for validation custom
               Custom: '#inputCustom',
               //  set text for validation password
               ErrorTextCustom: 'Must be 5-20 characters long custom.',
               //  set value required chars for validation custom form
               MinCharsCustom: '5'
                }
                //questionarie 
                $(settings.CheckReference).change(function()
                {
                    var ReferenceCheck= document.querySelector('input[name="referenceCheck"]:checked').value;
                    if(ReferenceCheck)
                    {
                        $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                    else
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorRadio);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
    
                $(settings.CheckforLeads).change(function()
                {
                    var LeadsCheck= document.querySelector('input[name="insuranceLead"]:checked').value;
                    if(LeadsCheck)
                    {
                        $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                    else
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorRadio);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
    
                $(settings.CheckforUnderstanding).change(function()
                {
                    var insuranceUnderstanding = document.querySelector('input[name="insuranceUnderstanding"]:checked').value;
                    if(insuranceUnderstanding)
                    {
                        $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                    else
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorRadio);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                
                $(settings.CheckforRoleUnderstanding).change(function()
                {
                    var roleUnderstanding = document.querySelector('input[name="roleUnderstanding"]:checked').value;
                    if(roleUnderstanding)
                    {
                        $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                    else
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorRadio);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
    
                $(settings.CheckforProspects).change(function()
                {
                    var prospectsCheck = document.querySelector('input[name="prospectsCheck"]:checked').value;
                    if(prospectsCheck)
                    {
                        $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                    else
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorRadio);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                
                $(settings.CheckforProspectsConversion).change(function()
                {
                    var prospectsConversion = document.querySelector('input[name="prospectsConversion"]:checked').value;
                    if(prospectsConversion)
                    {
                        $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                    else
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorRadio);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                
    
                $(settings.CheckforContacts).change(function()
                {                         
                    var checkbox = document.getElementsByName('contactCheck[]');
                    var ln = 0;
                    for(var i=0; i< checkbox.length; i++) {
                        if(checkbox[i].checked)
                            ln++
                    }
                    console.log(ln);
                    if(ln>0)
                    {
                        $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                    else
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorRadio);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
    
    
                
        
                $(settings.RFA).keyup(function()
                {
                    this.value=this.value.toUpperCase();
                    var RFA = this.value; 
                    console.log(RFA);
                    if(RFA)
                    {
                        if(isValidRFA(RFA))
                        {
                            $(this).parents('.form-group').addClass('has-success');
                            $(this).addClass('form-control-success');
                            $(this).parents('.form-group').removeClass('has-danger');
                            $(this).removeClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                        }
                        else{
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextRFA);
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                $(settings.consultantName).keyup(function(e)
                {
                    var ConsultantName = $.trim($(settings.consultantName).val()); //extract value  
                    if(ConsultantName)
                    {
                        if(isValidName(ConsultantName))
                        {
                            $(this).parents('.form-group').addClass('has-success');
                            $(this).addClass('form-control-success');
                            $(this).parents('.form-group').removeClass('has-danger');
                            $(this).removeClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                        }
                        else{
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text(settings.ErrorAlpha);
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                            e.preventDefault();
                        }
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                $(settings.employeeName).keyup(function()
                {
                    var EmployeeName = $.trim($(settings.employeeName).val()); //extract value  
                    if(EmployeeName)
                    {
                        if(isValidName(EmployeeName))
                        {
                            $(this).parents('.form-group').addClass('has-success');
                            $(this).addClass('form-control-success');
                            $(this).parents('.form-group').removeClass('has-danger');
                            $(this).removeClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                        }
                        else{
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text(settings.ErrorAlpha);
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                $(settings.LineHrName).keyup(function()
                {
                    var LineHrName = $.trim($(settings.LineHrName).val()); //extract value  
                    if(LineHrName)
                    {
                        if(isValidName(LineHrName))
                        {
                            $(this).parents('.form-group').addClass('has-success');
                            $(this).addClass('form-control-success');
                            $(this).parents('.form-group').removeClass('has-danger');
                            $(this).removeClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                        }
                        else{
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text(settings.ErrorAlpha);
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
            //employee code
                $(settings.EmployeeCode).keyup(function()
                {
                    this.value=this.value.toUpperCase();
                    var EmployeeCode = this.value;
                    if(EmployeeCode)
                    {
                        if(isValidEmpCode(EmployeeCode))
                        {
                            $(this).parents('.form-group').addClass('has-success');
                            $(this).addClass('form-control-success');
                            $(this).parents('.form-group').removeClass('has-danger');
                            $(this).removeClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                        }
                        else{
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text("Please enter the correct format.");
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                //hrcode
                $(settings.LineHrCode).keyup(function()
                {
                    this.value=this.value.toUpperCase();
                    var LineHrCode = this.value;                    
                    if(LineHrCode)
                    {
                        if(isValidEmpCode(LineHrCode))
                        {
                            $(this).parents('.form-group').addClass('has-success');
                            $(this).addClass('form-control-success');
                            $(this).parents('.form-group').removeClass('has-danger');
                            $(this).removeClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                        }
                        else{
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text("Please enter the correct format.");
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                //for hiring function
                $(settings.hiring).change(function()
                {
                    var hire = $.trim($(settings.hiring).val()); //extract value  
                    if(hire==0)
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorDropdown);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                });
                //for hiring location
                $(settings.hiringLocation).change(function()
                {
                    var hiringLocation = $.trim($(settings.hiringLocation).val()); //extract value  
                    if(!hiringLocation)
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorDropdown);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                });
                //for candidate name
                $(settings.CandidateName).keyup(function()
                {
                    var CandidateName = $.trim($(settings.CandidateName).val()); //extract value  
                    if(CandidateName)
                    {
                        if(isValidName(CandidateName))
                        {
                            $(this).parents('.form-group').addClass('has-success');
                            $(this).addClass('form-control-success');
                            $(this).parents('.form-group').removeClass('has-danger');
                            $(this).removeClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                        }
                        else{
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text(settings.ErrorAlpha);
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
//                $(settings.DOB).keyup(function()
//                {
//                    console.log(this.value);
//                }
                //for email
                $(settings.emailID).keyup(function()
                {
                    var emailID = $.trim($(settings.emailID).val()); //extract value  
                    if(emailID)
                    {
                        if(isValidEmail(emailID))
                        {
                            $(this).parents('.form-group').addClass('has-success');
                            $(this).addClass('form-control-success');
                            $(this).parents('.form-group').removeClass('has-danger');
                            $(this).removeClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                        }
                        else{
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmail);
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                //for gender
                $(".gender-check").change(function()
                {
                    var gender= document.querySelector('input[name="gender"]:checked').value;
                    if(gender)
                    {
                       $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                    else
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorRadio);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                //for address
                $(settings.Address).keyup(function()
                {
                    var Address = $.trim($(settings.Address).val()); //extract value  
                    if(Address)
                    {
                        if(Address.length<=200)
                        {
                            $(this).parents('.form-group').addClass('has-success');
                            $(this).addClass('form-control-success');
                            $(this).parents('.form-group').removeClass('has-danger');
                            $(this).removeClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                        }
                        else{
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text(settings.ErrorAddressLength);
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                //for mobile
                $(settings.Mobile).keyup(function()
                {
                    var Mobile = $.trim($(settings.Mobile).val()); //extract value  
                    if(Mobile)
                    {
                        if(Mobile.length>10)
                        {
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextMobileLength);
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                        else
                        {
                            if(isValidMobile(Mobile))
                            {
                                $(this).parents('.form-group').addClass('has-success');
                                $(this).addClass('form-control-success');
                                $(this).parents('.form-group').removeClass('has-danger');
                                $(this).removeClass('form-control-danger');
                                $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                            }
                            else
                            {
                                $(this).parents('.form-group').addClass('has-danger');
                                $(this).addClass('form-control-danger');
                                $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextMobile);
                                $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                            }
                        }
                        
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                //for country
                $(settings.Country).change(function()
                {
                    var Country = $.trim($(settings.Country).val()); //extract value  
                    if(Country=='')
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorDropdown);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                });
                //for state
                $(settings.State).change(function()
                {
                    var State = $.trim($(settings.State).val()); //extract value  
                    if(State=='')
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorDropdown);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                });
                $("#city").change(function()
                {
                    var city = $.trim($("#city").val()); //extract value  
                    if(city=='')
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorDropdown);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                });
                //for zip
                $(settings.ZIP).keyup(function()
                {
                    var ZIP = $.trim($(settings.ZIP).val()); //extract value  
                    if(ZIP)
                    {
                        if(ZIP.length>6)
                        {
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text(settings.ZipErrorLength);
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                        else
                        {
                            if(isValidZip(ZIP))
                            {
                                $(this).parents('.form-group').addClass('has-success');
                                $(this).addClass('form-control-success');
                                $(this).parents('.form-group').removeClass('has-danger');
                                $(this).removeClass('form-control-danger');
                                $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                            }
                            else
                            {
                                $(this).parents('.form-group').addClass('has-danger');
                                $(this).addClass('form-control-danger');
                                $(this).parents('.form-group').find('.text-muted').text(settings.ZipError);
                                $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                            }
                        }
                        
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                //for marital status
                $(settings.MaritalStatus).change(function()
                {
                    var MaritalStatus = $.trim($(settings.MaritalStatus).val()); //extract value  
                    if(MaritalStatus=='')
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorDropdown);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                });
                //for dependants
                $(settings.Dependants).keyup(function()
                {
                    var Dependants = $.trim($(settings.Dependants).val()); //extract value  
                    if(Dependants)
                    {
                        if(isValidCode(Dependants))
                        {
                            $(this).parents('.form-group').addClass('has-success');
                            $(this).addClass('form-control-success');
                            $(this).parents('.form-group').removeClass('has-danger');
                            $(this).removeClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                                
                        }
                        else{
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text(settings.ErrorNumeric);
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                //for PAN
                $(settings.PAN).keyup(function()
                {
                    this.value = this.value.toUpperCase();
                    PAN = this.value;
                    if(PAN)
                    {
                        if(isValidPan(PAN))
                        {
                            if(PAN.length==10)
                                {
                                    if(doesPanExists(PAN))
                                        {
                                            $(this).parents('.form-group').addClass('has-danger');
                                            $(this).addClass('form-control-danger');
                                            $(this).parents('.form-group').find('.text-muted').text("PAN number already in use.");
                                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                                        }
                                    else{
                                        $(this).parents('.form-group').addClass('has-success');
                                        $(this).addClass('form-control-success');
                                        $(this).parents('.form-group').removeClass('has-danger');
                                        $(this).removeClass('form-control-danger');
                                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                                    }
                                }
                            else
                                {
                                    $(this).parents('.form-group').addClass('has-danger');
                                    $(this).addClass('form-control-danger');
                                    $(this).parents('.form-group').find('.text-muted').text(settings.ErrorPanLength);
                                    $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                                }
                        }
                        else{
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text(settings.ErrorPan);
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                //for years worked
                $(settings.YearsWorked).keyup(function()
                {
                    var YearsWorked = $.trim($(settings.YearsWorked).val()); //extract value  
                    if(YearsWorked)
                    {
                        if(isValidCode(YearsWorked))
                        {   
                            $(this).parents('.form-group').addClass('has-success');
                            $(this).addClass('form-control-success');
                            $(this).parents('.form-group').removeClass('has-danger');
                            $(this).removeClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                        }
                        else{
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text(settings.ErrorNumeric);
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                //for months worked
                $(settings.MonthsWorked).keyup(function()
                {
                    var MonthsWorked = $.trim($(settings.MonthsWorked).val()); //extract value  
                    if(MonthsWorked)
                    {
                        if(isValidCode(MonthsWorked))
                        {   
                            if(MonthsWorked>12)
                            {
                                $(this).parents('.form-group').addClass('has-danger');
                                $(this).addClass('form-control-danger');
                                $(this).parents('.form-group').find('.text-muted').text(settings.ErrorMonthsLength);
                                $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                            }
                            else
                            {
                                $(this).parents('.form-group').addClass('has-success');
                                $(this).addClass('form-control-success');
                                $(this).parents('.form-group').removeClass('has-danger');
                                $(this).removeClass('form-control-danger');
                                $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                            }
                            
                        }
                        else{
                            $(this).parents('.form-group').addClass('has-danger');
                            $(this).addClass('form-control-danger');
                            $(this).parents('.form-group').find('.text-muted').text(settings.ErrorNumeric);
                            $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                        }
                    }
                    else{
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorTextEmpty);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                //for insurance background check
                $(settings.InsuranceCheck).change(function()
                {
                    var InsuranceCheck= document.querySelector('input[name="insuranceCheck"]:checked').value;
                    if(InsuranceCheck)
                    {
                       $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                    else
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorRadio);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                //for army background check
                $(settings.ArmyCheck).change(function()
                {
                    var ArmyCheck= document.querySelector('input[name="ArmyCheck"]:checked').value;
                    if(ArmyCheck)
                    {
                       $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                    else
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorRadio);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
                $(settings.EmployedCheck).change(function()
                {
                    var EmployedCheck= document.querySelector('input[name="EmployedCheck"]:checked').value;
                    if(EmployedCheck)
                    {
                        
                        if(EmployedCheck=="Employed")
                            {
                                $('.ForEndDate').css('display','none');
                            }
                        else if (EmployedCheck=="Not Employed")
                            {
                                $('.ForEndDate').css('display','block');
                            }
                       $(this).parents('.form-group').addClass('has-success');
                        $(this).addClass('form-control-success');
                        $(this).parents('.form-group').removeClass('has-danger');
                        $(this).removeClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').css('display', 'none');
                    }
                    else
                    {
                        $(this).parents('.form-group').addClass('has-danger');
                        $(this).addClass('form-control-danger');
                        $(this).parents('.form-group').find('.text-muted').text(settings.ErrorRadio);
                        $(this).parents('.form-group').find('.text-muted').css('display', 'block');
                    }
                });
    function isValidRFA(RFA)
        {
            if(RFA.length==16)
            {
                 var pattern = new RegExp(/^[a-zA-z]{3}[\/][0-9]{6}[\/][0-9]{2}[\-][0-9]{2}$/);
 		         return pattern.test(RFA);
            }          
        }
        function isValidName(name)
        {
                 var pattern = new RegExp(/^[a-zA-Z]+/);
 		         return pattern.test(name);       
        }
        function isValidEmpCode(code)
        {
            console.log(code);
            
            var pattern = new RegExp(/^(P0)[0-9]{5}$/)
            return pattern.test(code)
        }
        function isValidCode(code)
        {
            var pattern = new RegExp(/^\d+$/);
 		     return pattern.test(code);               
        }
        function isValidEmail(email)
        {
             var pattern = new RegExp(/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/);
 		     return pattern.test(email); 
        }
        function isValidMobile(mobile)
        {
             var pattern = new RegExp(/^[6789]\d{9}$/);
 		     return pattern.test(mobile); 
        }
        function isValidZip(zip)
        {
             var pattern = new RegExp(/^[1-9][0-9]{5}$/);
 		     return pattern.test(zip); 
        }
        function isValidAadhar(Aadhar)
        {
             var pattern = new RegExp(/\d{4}\d{4}\d{4}/);
 		     return pattern.test(Aadhar); 
        }
        function doesPanExists(pan)
        {
            var panExists="";
            $.ajax({
                            url: "/checkPANSubmit",
                            dataType: "json", 
                            async:false,
                            data:JSON.stringify( {'PAN':pan} ),
                            type: "POST",
                            success: function(response) {
                                panExists = response.panExists;                                
                            },
                            error: function(error) {
                                console.log(error);
                            }
                        });  
                    console.log(panExists);
                     return panExists;
        }
        function isValidPan(pan)
        {
             var pattern = new RegExp(/[a-zA-z]{5}\d{4}[a-zA-Z]{1}/);
 		     return pattern.test(pan)
        }
        
        function isValidYear(year)
        {
            var currentDate = new Date();
            var currentYear = currentDate.getFullYear();
            if(currentYear<year)
            {
                return false;
            }
            else
            {
                 var pattern = new RegExp(/^(19|20)\d{2}$/);
 		         return pattern.test(year);                    
            }
        }
        function isValidMonths(months)
        {
            var pattern = new RegExp(/^\d+$/);
            if(pattern.test(months))
            {
                if(months>12)
                    return false;
                else
                    return true;
            }
            else
                return false;
        }
        function isValidDOB(CandidateDob)
        {
            var mydate = new Date(CandidateDob);
            var dobMonth=mydate.getMonth()+1;
            var dobDay= mydate.getDate();
            var dobYear = mydate.getFullYear();

            var currentDate = new Date();
            var currentMonth = currentDate.getMonth()+1;
            var currrentDay =  currentDate.getDate();
            var currentYear = currentDate.getFullYear();
            var age = currentYear - dobYear;
            var m = currentMonth - dobMonth;
            if (m < 0 || (m === 0 && currrentDay < dobDay)) {
                age--;
            }

            if(age>=18)
            {
               return true;
            }
            else
            {
               return false;
            }
        }
        function genPDF()
        {
            html2canvas(document.getElementById("candidateForm"),{
                onrendered: function (canvas){
                    var img = canvas.toDataURL("image/png");
                    var doc = new jsPDF();
                    doc.addImage(img,'JPEG',20,20);
                    doc.save('test.pdf');
                }
            });
        }
}
        
        