# Practical

Steps to run :

1.Download project as a zip file 

2.Navigate to the downloaded folder,unzip the files and Setup Virtual Environment using Command Prompt "virtualenv env" in the current directory. 

    2.1 Navigate to virtual environment env/scripts/activate

3.run command pip install -r requirements.txt to install dependencies

4.Open MySQL workbench or prefferred client of your choice and import the practical.sql file. 

5.In command prompt, current project directory (same as above), run command "application.py

6. Open local browser and run " http://http://127.0.0.1:5000"